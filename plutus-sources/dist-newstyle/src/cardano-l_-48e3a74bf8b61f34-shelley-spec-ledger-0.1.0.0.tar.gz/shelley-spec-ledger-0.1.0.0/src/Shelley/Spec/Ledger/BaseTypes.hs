module Shelley.Spec.Ledger.BaseTypes
  {-# DEPRECATED "Use 'import Cardano.Ledger.BaseTypes' instead." #-}
  (module X)
where

import Cardano.Ledger.BaseTypes as X
